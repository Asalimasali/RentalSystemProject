import java.util.Calendar;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Date date = new Date(2015-1900, 3, 5);
        Game game = new Game("Clash Royal", "strategic" ,date, 123, 25000, "mobile", "supercell");
        Customer customer = new Customer("asal" , "asal.salimi1382@gamil.com" , "+989306751595" , "Qaemshahr" , 1);
        Book book = new Book("ditel" , "learning" , date , 456 , 20000 , "ditels" , "ditel" );
        Movie movie = new Movie("got" , "drama" , date , 789 , 30000 , "Mark Mylod" , "Jon Snow");

        //game.rentItem(customer);

    }
}